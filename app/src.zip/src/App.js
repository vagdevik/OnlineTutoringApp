import React, {Component} from 'react';
import { BrowserRouter as Router, Route, Routes as Switch } from 'react-router-dom'
import Tutors from './TutorsList';
import Home from './Home';
import TutorDetails from './TutorDetails';
import Navbar from './Navbar'; 
import Footer from './Footer';
import {
  Container, Row, Col
 } from 'reactstrap';

class App extends Component {




  
      render () {
         return (
          <Router>
            <div className="App">
           <Navbar/>
          
           <Switch>
                <Route path="/" element={<Home />} /> 
                <Route path="/Tutors/:id" element={<TutorDetails />} /> 
              </Switch>
            
            <Footer />
          
            </div>
          </Router>
        );
 
      }
}

export default App;