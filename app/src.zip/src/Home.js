import React, {Component} from 'react';
import { BrowserRouter as Router, Route, Routes as Switch } from 'react-router-dom'
import Tutors from './TutorsList';
import {
  Container, Row, Col
 } from 'reactstrap';



class Home extends Component {
    
      state = {
        availableOnly: false,
        tutors:[], 
        search:''  
      }

      componentDidMount(){

        fetch('tutors.json', {
          headers : { 
            'Content-Type': 'application/json',
             'Accept': 'application/json'
          }
        })
        .then( res => res.json() )
        .then( (data) => {
            this.setState({ tutors: data })
        })
        .catch(console.log)
      }

      
      

      render () {
         return (
          <div>
            <container>
           <Row >
             <div align="center">
             <input  type="text" placeholder="Name, Subject Search" style={{  width:"300px",marginTop:"200px",marginLeft:"15px"}} onChange={(e)=>{this.setState({search:(e.target.value)})}}/>
             </div>
             </Row>
             <br></br>
             <Row  >
            <Tutors tutorsData={this.state.tutors}  search={this.state.search}/>
            </Row>
            </container>
          </div> 
        );
 
      }
}

export default Home;