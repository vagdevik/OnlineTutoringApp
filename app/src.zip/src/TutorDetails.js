import { useParams } from "react-router-dom";
import {useLocation} from "react-router-dom";
import React, { useState } from 'react';
import Calendar from 'react-calendar';

const TutorDetails = () => {
  const { id } = useParams();
  const location = useLocation();
  console.log(location.state);

  const image_style = {
    height: 200,
    width: 200,
  };

  const [value, onChange] = useState(new Date());

  return (
    <div style={{ marginTop:"200px",marginBottom: "80px" 
  }}>
      <div className="tutorPage">
      <img src={location.state.image_url} alt="mentor_1" style={image_style}></img>
      <h2>{location.state.name}</h2>
      <p>{location.state.rating}<i className="fa fa-star" aria-hidden="true"></i></p>

      <i className="fa fa-book" ><b> Expertise </b></i>
      <p>{location.state.subject}</p>
      
      <i class="fa fa-user" aria-hidden="true"><b> About Me </b></i>
      <p>{location.state.about_me}</p>

      <i className="fa fa-certificate" aria-hidden="true"><b> Certifications</b></i>
    
        
      {
        location.state.certifications.map(function(c){
          return <p> {c} </p>
        })
      }
      




      <i class="fa fa-clock-o" aria-hidden="true"><b> Working Hours</b></i>
      <p>{location.state.working_hours}</p>
      <button type="button" className="btn btn-warning alignCenter">
        <i className="fa fa-calendar" aria-hidden="true"></i> Schedule a Meeting
      </button>
      <div className="row">
        <div className="col-sm-4"></div>
        <div className="col-sm-4">
        <br></br>
          <div className="row">
            <div className="col-sm-4">
              <button type="button" className="btn btn-light alignCenter">
              <i className="fa fa-star-o" ></i>
              </button>
              <p>Rate the Tutor</p>
            </div>
            <div className="col-sm-4">
              <button type="button" className="btn btn-light alignCenter">
                <i className="fa fa-comment-o" aria-hidden="true"></i>
              </button>
              <p>Comment </p>
            </div>
            <div className="col-sm-4">
              <button type="button" className="btn btn-light alignCenter">
                <i className="fa fa-heart-o" aria-hidden="true"></i>
              </button> 
              <p>Add to favorites</p>
              
              
            </div>
          </div>
        </div>
      </div>
      <div className="col-sm-4"></div>
      </div>
        <div className= "row">
          <div className="col-sm-3"></div>
          <div className="col-sm-6">
            <Calendar  style={{height:"300px", width:"500px"}} onChange={onChange} value={value} />
            </div>
          <div className="col-sm-3"></div>
        <div/>
    
        </div>
   
    </div>
  );
}





export default TutorDetails;