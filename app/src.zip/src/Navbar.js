import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';


const Navbar = () => {
	return (
		<div>
		<nav class="navbar navbar-expand-sm navbar-light bg-dark fixed-top bar1 navbar-custom"> 
            <button type="button" data-bs-toggle="collapse" data-bs-target="#firstNav" 
            class = "navbar-toggler" aria-controls = "firstNav" aria-expanded = "false" aria-label="Toggle Navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="firstNav">
             <ul class="navbar-nav ms-auto">
              <li class="nav-item active"><a href="login.html" class="nav-link" ><i class="fa fa-sign-in"></i> Log In</a></li>
              <li class="nav-item active"><a href="signup.html" class="nav-link"><i class="fa fa-user"></i> Sign Up</a></li>	
            </ul>            
          </div>
        </nav>

        <nav class="bar2 navbar navbar-expand-lg navbar-light py-4 fixed-top" style={{marginTop:"50px",paddingBottom:"10px",background:"#ff6347",color:"blue"}}>
          <div class="container">
            <a href="part1.html" class="navbar-brand h1"><img class="d-inline-block align-top" src="graduation-cap.png" width="40" height="40" style={{marginTop:"15px"}}/><font color="white" size="25"> TutMe</font></a>

            <button type="button" data-bs-toggle="collapse" data-bs-target="#secondNav" 
            class = "navbar-toggler" aria-controls = "secondNav" aria-expanded = "false" aria-label="Toggle Navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="secondNav">
              <ul class="navbar-nav">
                <li class="nav-item"><a href="tutors.html" class="nav-link" style={{fontSize:"25px", marginTop:"12px",marginLeft:"15px"}}>TUTORS</a></li>
                <li class="nav-item"><a href="courses.html" class="nav-link" style={{fontSize:"25px", marginTop:"12px",marginLeft:"15px"}}>COURSES</a></li>
				  <li class="nav-item"><a href="progress.html" class="nav-link" style={{fontSize:"25px", marginTop:"12px",marginLeft:"15px"}}>PROGRESS</a></li>
              </ul>
			</div>
			</div>

      

         
        </nav>
      </div>
    
	);
}

export default Navbar;