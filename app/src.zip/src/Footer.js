import React from 'react';

const Footer = () => {
	return (	   
      <div class="row footer-row-bg"  style={{paddingbottom:0}}>
          <div>Copyright &copy; 2022 TutMe Inc.</div>
          <p><a href="#">Home</a>/<a href="#">About</a>/<a href="#">Contact</a>/<a href="#">Browse</a></p>
      </div>
	);
}

export default Footer;